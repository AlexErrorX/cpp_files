#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
 struct student {
	char student_ID[21];
	char name[41];
	char gender;
	int old;
	int grade;
	char wheres[41];
	student* pNext = NULL;
};
student* pStart = NULL;
student* pTail = NULL;
void init() {
	char a[4] = "end";
	student* p = new student;
	while (true) {
		cin >> p->student_ID;
		while (strcmp(p->student_ID, a)!=0) {
			student* p = new student;
			cin >> p->name >> p->gender >> p->old >> p->grade >> p->wheres;
			if (pStart == NULL) {
				pStart = p;
			}
			else {
				pTail->pNext = p;
			}
			pTail = p;
		}
	}
		
		
	
	
}