#include"��ͷ.h"
int main() {
	init();
	return 0;
}